# Guida per studenti: pipeline, controlli locali e Pull Request

Questa repository è un template iniziale. Le cartelle `backend/` e `frontend/` sono volutamente vuote: il codice applicativo deve essere creato dagli studenti. La pipeline di Continuous Integration (CI) è già configurata in `.github/workflows/ci.yml`.

> **Regola fondamentale:** non lavorare direttamente su `main`. Ogni attività va sviluppata in un branch dedicato e proposta tramite Pull Request verso `main`.

## 1. Struttura iniziale

```text
.
├── .github/
│   └── workflows/
│       └── ci.yml
├── backend/                 # vuota nel template
├── frontend/                # vuota nel template
├── docs/
│   └── readme.md
├── .editorconfig
├── .gitattributes
├── .gitignore
├── Directory.Build.props
└── LogisticsEngine.slnx
```

## 2. Prerequisiti

Prima di iniziare, installare:

- Git;
- .NET SDK 10;
- un editor o IDE, per esempio Visual Studio, Visual Studio Code o Rider;
- accesso alla repository GitHub assegnata.

Verificare le installazioni:

```bash
git --version
dotnet --version
```

Il comando `dotnet --version` deve mostrare una versione `10.x`. Se mostra una versione diversa o il comando non esiste, installare l'SDK corretto prima di continuare.

Configurare nome ed e-mail Git, se non è già stato fatto sul computer:

```bash
git config --global user.name "..."
git config --global user.email "email-usata-su-github@example.com"
```

## 3. Quando parte la pipeline

GitHub Actions avvia la pipeline in due casi:

1. a ogni `push` su qualunque branch;
2. all'apertura o all'aggiornamento di una Pull Request diretta verso `main`.

Se fate più push sullo stesso branch in poco tempo, l'esecuzione precedente viene annullata e resta attiva soltanto quella più recente. Questo evita di consumare tempo su una versione del codice già superata.

Nel template vuoto la pipeline conclude con successo, ma segnala che non esistono ancora progetti backend. I controlli .NET completi si attivano automaticamente appena in `backend/` compare almeno un file `.csproj` aggiunto alla soluzione `LogisticsEngine.slnx`.

## 4. Cosa controlla la pipeline

Il job visibile nella Pull Request si chiama **Build, analyze and test** ed esegue gli step nell'ordine seguente.

| Step | Comando o azione | Scopo | Quando fallisce |
|---|---|---|---|
| Checkout | `actions/checkout` | Scarica il contenuto del branch | Repository non accessibile |
| Setup .NET | `actions/setup-dotnet` | Installa .NET SDK 10 sul runner | Versione non disponibile o configurazione errata |
| Detect backend projects | ricerca dei file `.csproj` | Capisce se il template contiene già un backend | Non blocca il template vuoto |
| Restore | `dotnet restore` | Scarica le dipendenze NuGet | Pacchetto/versione inesistente, feed non raggiungibile o progetto non presente nella soluzione |
| Build | `dotnet build` | Compila in modalità `Release` ed esegue gli analyzer | Errore di compilazione o qualunque warning |
| Format | `dotnet format --verify-no-changes` | Verifica le regole di `.editorconfig` | Il codice non è formattato o contiene violazioni correggibili |
| Unit test + coverage | `dotnet test` con Coverlet | Esegue gli unit test e misura Domain + Application | Test fallito o line coverage totale inferiore al 50% |
| Architecture tests | `dotnet test` | Verifica le regole architetturali definite dal progetto di test | Una regola architetturale è violata |
| Upload artifacts | `actions/upload-artifact` | Salva report coverage e risultati `.trx` | Non blocca la CI se i file non esistono |

Le impostazioni comuni dei progetti .NET sono in `Directory.Build.props`. In particolare:

- il target è `net10.0`;
- nullable reference types e analyzer .NET sono attivi;
- gli stili definiti in `.editorconfig` vengono controllati durante la build;
- tutti i warning vengono trattati come errori.

### Percorsi convenzionali dei test

La pipeline riconosce automaticamente questi due progetti:

```text
backend/tests/LogisticsEngine.UnitTests/LogisticsEngine.UnitTests.csproj
backend/tests/LogisticsEngine.ArchitectureTests/LogisticsEngine.ArchitectureTests.csproj
```

Se i progetti vengono chiamati o posizionati diversamente, aggiornare insieme al docente le variabili `UNIT_TEST_PROJECT` e `ARCHITECTURE_TEST_PROJECT` in `.github/workflows/ci.yml`. Non rinominare i percorsi solo per far sparire un controllo.

Per applicare la soglia di coverage, il progetto degli unit test deve includere il pacchetto `coverlet.msbuild`.

## 5. Preparare il lavoro: Issue e branch

Prima di modificare il codice, creare o scegliere una Issue che descriva un'attività precisa, per esempio `#12 Implementare la registrazione di una spedizione`.

Aggiornare `main` locale:

```bash
git switch main
git pull --ff-only origin main
```

Creare un branch partendo da `main` aggiornato:

```bash
git switch -c feature/12-registrazione-spedizione
```

Usare nomi brevi, in minuscolo e separati da trattini. Formati consigliati:

- `feature/12-descrizione` per una funzionalità;
- `fix/18-descrizione` per una correzione;
- `docs/21-descrizione` per sola documentazione;
- `refactor/25-descrizione` per una riorganizzazione senza modifica del comportamento.

Verificare sempre il branch attivo:

```bash
git branch --show-current
```

L'output non deve essere `main`.

## 6. Sviluppare e creare commit leggibili

Durante il lavoro, controllare frequentemente lo stato:

```bash
git status
git diff
```

Aggiungere soltanto i file pertinenti all'attività; evitare `git add .` se non si è controllato cosa include:

```bash
git add percorso/del/file
git status
git diff --cached
```

Creare un commit con un messaggio chiaro:

```bash
git commit -m "feat: aggiunge la registrazione delle spedizioni"
```

Non committare segreti, password, token, file `.env`, cartelle `bin/`, `obj/`, `coverage/` o configurazioni personali dell'IDE.

## 7. Controlli locali obbligatori prima del push

Eseguire i comandi dalla radice della repository, cioè dalla cartella che contiene `LogisticsEngine.slnx`.

### 7.1 Ripristino delle dipendenze

```bash
dotnet restore LogisticsEngine.slnx
```

### 7.2 Compilazione Release

```bash
dotnet build LogisticsEngine.slnx --no-restore --configuration Release
```

La build deve terminare con **0 errori e 0 warning**. Non ignorare un warning: la pipeline lo tratta come errore.

### 7.3 Verifica della formattazione

```bash
dotnet format LogisticsEngine.slnx --verify-no-changes --no-restore
```

Se fallisce, applicare la formattazione:

```bash
dotnet format LogisticsEngine.slnx
```

Controllare le modifiche con `git diff`, quindi ripetere il comando con `--verify-no-changes`.

### 7.4 Unit test e soglia di coverage

Quando esiste il progetto degli unit test, eseguire lo stesso comando della CI:

```bash
dotnet test backend/tests/LogisticsEngine.UnitTests/LogisticsEngine.UnitTests.csproj \
  --no-build --configuration Release \
  --logger "trx;LogFileName=unit-tests.trx" \
  /p:CollectCoverage=true \
  /p:CoverletOutputFormat=cobertura \
  /p:CoverletOutput=../../../coverage/ \
  /p:Threshold=50 \
  /p:ThresholdType=line \
  /p:ThresholdStat=total \
  /p:Include="[LogisticsEngine.Domain]*%2c[LogisticsEngine.Application]*"
```

Tutti i test devono passare e la line coverage complessiva di Domain + Application deve essere almeno il 50%. La soglia è un minimo, non un obiettivo: testare anche casi limite e casi non validi.

### 7.5 Test architetturali

Quando esiste il relativo progetto, eseguire:

```bash
dotnet test backend/tests/LogisticsEngine.ArchitectureTests/LogisticsEngine.ArchitectureTests.csproj \
  --no-build --configuration Release \
  --logger "trx;LogFileName=architecture-tests.trx"
```

### 7.6 Controllo finale Git

```bash
git status
git diff --check
git log --oneline origin/main..HEAD
```

Prima del push assicurarsi che:

- tutti i controlli applicabili siano verdi;
- non ci siano file temporanei o segreti;
- i commit riguardino soltanto l'Issue scelta;
- non ci siano modifiche non volute ancora fuori dai commit.

Se il backend non contiene ancora alcun `.csproj`, i comandi .NET non sono applicabili: in quel caso la CI mostra soltanto il messaggio di template vuoto. Appena viene creato il primo progetto, i primi tre controlli diventano obbligatori.

## 8. Aggiornare il branch prima del push

Recuperare lo stato più recente del repository remoto:

```bash
git fetch origin
git rebase origin/main
```

Se compaiono conflitti:

1. aprire i file indicati da `git status`;
2. scegliere il contenuto corretto ed eliminare i marcatori `<<<<<<<`, `=======`, `>>>>>>>`;
3. eseguire `git add percorso/del/file-risolto`;
4. continuare con `git rebase --continue`;
5. ripetere tutti i controlli locali, perché il codice è cambiato.

Se non sapete quale versione conservare, fermatevi e chiedete al docente o al gruppo. Non risolvete un conflitto cancellando codice senza comprenderlo.

## 9. Push del branch

Al primo push del branch:

```bash
git push -u origin feature/12-registrazione-spedizione
```

Nei push successivi è sufficiente:

```bash
git push
```

Dopo il push, aprire la scheda **Actions** su GitHub e verificare l'esecuzione. Se è rossa, aprire il job **Build, analyze and test**, individuare il primo step fallito, correggere il problema in locale e fare un nuovo push.

Se avete già pubblicato il branch e successivamente lo avete ribasato, un normale push può essere rifiutato. Prima coordinatevi con gli altri membri del gruppo; solo se nessun altro sta lavorando sul branch usate:

```bash
git push --force-with-lease
```

Non usare `--force`: può sovrascrivere modifiche remote che non avete visto.

## 10. Creare la Pull Request

Su GitHub:

1. aprire la repository;
2. selezionare **Pull requests**;
3. fare clic su **New pull request**;
4. impostare `base: main`;
5. impostare `compare: feature/12-registrazione-spedizione`;
6. controllare la scheda **Files changed**: non devono comparire file estranei all'Issue;
7. inserire titolo e descrizione;
8. fare clic su **Create pull request**;
9. assegnare i reviewer richiesti.

Titolo consigliato:

```text
feat: aggiunge la registrazione delle spedizioni
```

Descrizione consigliata:

```markdown
## Obiettivo

Closes #12

Descrivere in poche righe cosa risolve la Pull Request.

## Modifiche principali

- modifica 1;
- modifica 2.

## Verifiche eseguite

- [ ] build Release senza warning;
- [ ] formattazione verificata;
- [ ] unit test superati;
- [ ] coverage almeno al 50%;
- [ ] test architetturali superati;
- [ ] nessun segreto o file generato incluso.

## Scelte progettuali e note per il reviewer

Spiegare decisioni non ovvie, limiti conosciuti o aspetti su cui si desidera un parere.
```

Usare `Closes #12` soltanto se la Pull Request completa davvero l'Issue: GitHub la chiuderà automaticamente al merge.

## 11. Gestire pipeline e code review

Dopo l'apertura della Pull Request:

1. attendere che **Build, analyze and test** diventi verde;
2. se fallisce, correggere in locale e pubblicare un nuovo commit sullo stesso branch;
3. rispondere ai commenti del reviewer;
4. non aprire una nuova Pull Request per ogni correzione: i nuovi push aggiornano quella esistente;
5. risolvere una conversazione soltanto dopo aver applicato o discusso la modifica;
6. chiedere una nuova review quando tutte le osservazioni sono state gestite.

Una Pull Request è pronta al merge solo quando:

- la pipeline è verde;
- il branch è aggiornato rispetto a `main`;
- i reviewer richiesti hanno approvato;
- non restano conversazioni aperte;
- non ci sono conflitti;
- la checklist della descrizione è completa.

Il merge deve essere eseguito secondo la strategia indicata dal docente. Dopo il merge, aggiornare la copia locale e rimuovere il branch locale ormai concluso:

```bash
git switch main
git pull --ff-only origin main
git branch -d feature/12-registrazione-spedizione
```

## 12. Errori comuni e soluzione

### `The command could not be loaded` oppure SDK non trovato

Controllare `dotnet --version` e installare .NET SDK 10. Riavviare il terminale dopo l'installazione.

### Restore fallito

Controllare la connessione, il nome e la versione del pacchetto NuGet e verificare che il progetto sia incluso in `LogisticsEngine.slnx`.

### Build fallita per un warning

Leggere codice e posizione nel log. Correggere la causa: `TreatWarningsAsErrors` è intenzionale e non va disattivato per aggirare il controllo.

### Format check fallito

Eseguire `dotnet format LogisticsEngine.slnx`, controllare il diff e ripetere la verifica.

### Coverage inferiore al 50%

Aprire il report in `coverage/`, individuare le parti non esercitate e aggiungere test significativi. Non escludere codice dalla misurazione per superare artificialmente la soglia.

### La pipeline non parte

Verificare che il push sia arrivato su GitHub, che il file `.github/workflows/ci.yml` esista nel branch e che GitHub Actions sia abilitato nella repository.

### La pipeline è verde ma gli unit test non compaiono

Controllare che i progetti di test usino esattamente i percorsi convenzionali indicati sopra. La pipeline salta uno specifico gruppo di test finché il relativo `.csproj` non esiste.

### Il push è rifiutato

Eseguire `git fetch origin`, leggere il messaggio di Git e integrare le modifiche remote. Non forzare il push senza capire perché è stato rifiutato.

## Checklist rapida prima di ogni Pull Request

- [ ] Sto lavorando su un branch dedicato, non su `main`.
- [ ] Il branch parte da un `main` aggiornato.
- [ ] Ho controllato `git diff` e `git diff --cached`.
- [ ] Restore e build Release terminano correttamente.
- [ ] `dotnet format --verify-no-changes` passa.
- [ ] Tutti i test applicabili passano.
- [ ] La coverage è almeno al 50%.
- [ ] Non sto pubblicando segreti o file generati.
- [ ] La Pull Request punta da un branch dedicato verso `main`.
- [ ] La descrizione collega l'Issue e spiega modifiche e verifiche.
