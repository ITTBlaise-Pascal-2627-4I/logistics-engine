namespace LogisticsEngine.SharedKernel;

public enum ErrorType
{
    Failure,
    Validation,
    Problem,
    NotFound,
    Conflict
}
